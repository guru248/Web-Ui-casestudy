create database truYum;
use truYum;

create table menu_item(
MenuID int auto_increment primary key,
ItemName varchar(30),
Price decimal(5,2),
ItemActive varchar(5),
DateOfLaunch date,
Category varchar(20),
FreeDelivery varchar(5)
);

create table userdetails(
UserID int auto_increment primary key,
UserName varchar(25)
);

create table cart(
CartID int auto_increment primary key,
UserID int,
MenuID int,
constraint fk_cart_userid foreign key (UserID) references userdetails(UserID),
constraint fk_cart_enu_item foreign key (MenuID) references menu_item(MenuID)
);



