-- 1. a
insert into menu_item(ItemName,Price,ItemActive,DateOfLaunch,Category,FreeDelivery) values (
'Sandwich',99.00,'Yes','2017-03-15','Main Course','Yes'
);
insert into menu_item(ItemName,Price,ItemActive,DateOfLaunch,Category,FreeDelivery) values (
'Burger',129.00,'Yes','2017-12-23','Main Course','No'
);
insert into menu_item(ItemName,Price,ItemActive,DateOfLaunch,Category,FreeDelivery) values (
'Pizza',149.00,'Yes','2017-08-21','Main Course','No'
);
insert into menu_item(ItemName,Price,ItemActive,DateOfLaunch,Category,FreeDelivery) values (
'French Fries',57.00,'No','2017-07-02','Starters','Yes'
);
insert into menu_item(ItemName,Price,ItemActive,DateOfLaunch,Category,FreeDelivery) values (
'Chocolate Brownie',32.00,'Yes','2017-02-11','Dessert','Yes'
);

-- 1. b
Select ItemName as Name,
concat('Rs. ', Price) as Price,
ItemActive as 'Active', 
DateOfLaunch as 'Date of Launch', Category, 
FreeDelivery as 'Free Delivery'
from menu_item;

-- 2. a
Select ItemName as Name,
concat('Rs. ', Price) as Price,
Category
from menu_item
where ItemActive='yes' and DateOfLaunch<now();

-- 3. a
Select ItemName as Name,
FreeDelivery as 'Free Delivery',
concat('Rs. ', Price) as Price
from menu_item
group by MenuID;

-- 3. b
update menu_item
set ItemName='Sandwich'
where MenuID=1;

-- 4. a
insert into userdetails(UserName) values('abcd'),('efgh');
insert into cart(UserID,MenuID) values (2,2),(2,3),(2,4);

-- 5. a
Select ItemName as Name,
FreeDelivery as 'Free Delivery',
concat('Rs. ', Price) as Price
from menu_item
inner join cart
on menu_item.MenuID = cart.MenuID
inner join userdetails
on userdetails.UserID=cart.UserID
where cart.userID=2;

-- 5. b
Select
concat('Rs. ', cast(sum(Price) as char)) as 'Total'
from menu_item
inner join cart
on menu_item.MenuID = cart.MenuID
inner join userdetails
on userdetails.UserID=cart.UserID
where cart.userID=2;

-- 6. a
delete from cart
where UserID=2 and MenuID=2;
